# Copy files into train and val directories 
# Populate train.txt and val.txt
import numpy as np
import os
import shutil
import random

data_dir = '../../../data'
#classes = ['calendar','email','programming','social_media','word_processing','web_shopping',
#           'finance','news','music_editing','picture_editing','video_editing','watching_video','web_browsing','web_forum']
classes = ['calendar','email','programming','social_media','word_processing']
train_file = "small_train.txt"
val_file = "small_val.txt"
test_file = "small_test.txt"
train_dir = "small_train"
val_dir = "small_val"
test_dir = "small_test"

# Check if directories already exist - if not create them
try:
    os.stat(train_dir)
except:
    os.mkdir(train_dir)
try:
    os.stat(val_dir)
except:
    os.mkdir(val_dir) 
try: 
	os.stat(test_dir)
except: 
	os.mkdir(test_dir)

num_train_per_class = 400
num_val_per_class = 100

for c in classes: 
	files = [file for file in os.listdir(os.path.join(data_dir,c))]
	random.shuffle(files)
	tr_ind = 0
	val_ind = 0
	for fn in files:
		print fn
		if not os.path.splitext(fn)[1]==".JPEG":
			continue
		filepath = os.path.join(data_dir,c,fn)
		if tr_ind<num_train_per_class: # copy to train directory
			shutil.copyfile(filepath,os.path.join(train_dir,fn))
			# add the file to the train.txt file with class label
			f = open(train_file,'a')
			f.write(fn+" "+str(classes.index(c))+'\n') # python will convert \n to os.linesep
			f.close() # you can omit in most cases as the destructor will call if
			tr_ind+=1
		else: 
			if val_ind<num_val_per_class: # copy to val directory
				shutil.copyfile(filepath,os.path.join(val_dir,fn))
				# add the file to the val.txt file with class label
				f = open(val_file,'a')
				f.write(fn+" "+str(classes.index(c))+'\n') # python will convert \n to os.linesep
				f.close() # you can omit in most cases as the destructor will call if
				val_ind+=1
			else: # copy the rest to test directory (for use later)
				shutil.copyfile(filepath,os.path.join(test_dir,fn))
				f = open(test_file,'a')
				f.write(fn+" "+str(classes.index(c))+'\n') # python will convert \n to os.linesep
				f.close() # you can omit in most cases as the destructor will call if

