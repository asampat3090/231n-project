from PIL import Image 
import os

def hamming_distance(s1, s2):
    """Return the Hamming distance between equal-length sequences"""
    if len(s1) != len(s2):
        raise ValueError("Undefined for sequences of unequal length")
    return sum(ch1 != ch2 for ch1, ch2 in zip(s1, s2))

def dhash(image, hash_size = 8):
    # Grayscale and shrink the image in one step.
    image = image.convert('L').resize(
        (hash_size + 1, hash_size),
        Image.ANTIALIAS,
    )

    pixels = list(image.getdata())

    # Compare adjacent pixels.
    difference = []
    for row in xrange(hash_size):
        for col in xrange(hash_size):
            pixel_left = image.getpixel((col, row))
            pixel_right = image.getpixel((col + 1, row))
            difference.append(pixel_left > pixel_right)

    # Convert the binary array to a hexadecimal string.
    decimal_value = 0
    hex_string = []
    for index, value in enumerate(difference):
        if value:
            decimal_value += 2**(index % 8)
        if (index % 8) == 7:
            hex_string.append(hex(decimal_value)[2:].rjust(2, '0'))
            decimal_value = 0

    return ''.join(hex_string)

# Run through all images and remove near duplicates
filelist = os.listdir('.')
print "Checking current directory for possible near duplicates..."
for i in xrange(len(filelist)-1):
	f1 = filelist[i]
	if os.path.splitext(f1)[1]==".JPEG":
		try: 
			img1 = Image.open(f1)
		except IOError:
			print "cannot open %s as image" % f1
			continue
	for j in xrange(i+1,len(filelist)):
		f2 = filelist[j]
		if os.path.splitext(f1)[1]==".JPEG":
			#print "Checking %s and %s for possible duplicate" % (f1,f2)
			try:
				img2 = Image.open(f2)
			except IOError:
				print "cannot open %s as image" % f2
				continue
			diff = hamming_distance(dhash(img1),dhash(img2))
			if diff<4: #set threshold to 4
				# Remove one of the filelist
				print "%s and %s are too similar" % (f1,f2)
				os.remove(f2)
				print "removed %s - one of the duplicates" % f2