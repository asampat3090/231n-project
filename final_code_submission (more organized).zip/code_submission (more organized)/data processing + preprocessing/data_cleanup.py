import numpy as np
import os
from PIL import Image

dir_arr = ['calendar','email','programming','social_media','word_processing','web_shopping',
           'finance','news','music_editing','picture_editing','video_editing','watching_video','web_browsing','web_forum']

for dir in dir_arr:
	current_dir = dir

	# Remove all files that have size of <1 kb
	for fn in os.listdir(current_dir):
		filepath = os.path.join(current_dir,fn)
		if os.path.isfile(filepath):
			if os.stat(filepath).st_size<1000:
				os.remove(filepath)
				print "removed %s - file size too small" % filepath

	# Remove files with less than 200 pixels in either direction
	# Remove files with less a height > width
	for fn in os.listdir(current_dir):
		filepath = os.path.join(current_dir,fn)
		if os.path.isfile(filepath) and fn[0]!='.':
			try:
				im=Image.open(filepath)
			except:
				os.remove(filepath)
				print "removed %s - not an image processable by PIL" % filepath
				continue
			w, h  = im.size # (width,height) tuple
			if w<200 or h<200: # remove images that are too small
				os.remove(filepath)
				print "removed %s - image size too small" % filepath
			elif h>w:
				os.remove(filepath)
				print "removed %s - image has incorrect aspect ratio" % filepath

	# Rename files to simple numbers
	file_num = 1
    # First pass just add something to filepath
	for fn in os.listdir(current_dir):
		filepath = os.path.join(current_dir,fn)
		if os.path.isfile(filepath) and fn[0]!='.':
			os.rename(filepath,filepath+"_temp")
    # Then rename all files - no conflicts
	for fn in os.listdir(current_dir):
		filepath = os.path.join(current_dir,fn)
		if os.path.isfile(filepath) and fn[0]!='.':
			new_path = os.path.join(current_dir,current_dir+"_"+str(file_num)+".JPEG")
			if not os.path.exists(new_path):
				os.rename(filepath,new_path)
				print "renamed file from %s to %s" % (filepath,new_path)
		file_num += 1

