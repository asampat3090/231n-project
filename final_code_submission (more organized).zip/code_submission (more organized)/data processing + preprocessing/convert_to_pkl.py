__author__ = 'anandsampat'
import cPickle as pickle
from PIL import Image
from os import listdir
from os.path import isfile,join
import sys
import random
import numpy as np
import gzip

# Create small dataset
num_images_per_class = 500
img_h = 32
img_w = 32
img_d = 3
classes = ['emails','calendars','social_media','webwordprocessing']
num_total = num_images_per_class*len(classes)

total_x = np.zeros((num_total,img_d,img_h,img_w))
total_y = np.zeros(num_total)


file_ind = 0
for c in classes:
    onlyfiles = [f for f in listdir(c) if isfile(join(c,f))]
    random.shuffle(onlyfiles)
    filestoadd = onlyfiles[0:num_images_per_class]
    for f in filestoadd:
        # add files to total
        if f!='.DS_Store':
            print join(c,f)
            img = Image.open(join(c,f))
            img = img.resize((img_h,img_w))
            img = np.asarray(img,dtype='float64')/256
            if len(img.shape)==3 and img.shape[2]==3:
                total_x[file_ind] = img.transpose(2,0,1).copy()
                total_y[file_ind] = classes.index(c)
                file_ind += 1

num_total = file_ind+1

# Split into train val and test sets.
rand_ind = np.random.permutation(total_x.shape[0])
total_x = total_x[rand_ind]
total_y = total_y[rand_ind]

f = gzip.open('screenshots.pkl.gz', 'wb')
pickle.dump((total_x,total_y.astype(int)), f)
f.close()

