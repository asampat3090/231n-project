import subprocess
import datetime
import time
import os
import sys
from PIL import Image
import multiprocessing as mp

'''
Take two system arguments:
	arg[1] - second delay between taking screenshots
	arg[2] - Total number of images we want 
	arg[3] - Base directory to store screenshots

'''
def resize_img(size,inpath,output):
	outpath = os.path.splitext(inpath)[0] + ".JPEG"
	im = Image.open(inpath)
	im.thumbnail(size, Image.ANTIALIAS)
	im.save(outpath,"JPEG")
	os.remove(inpath)
	output.put("done")


second_delay = int(sys.argv[1])
total_num_images = int(sys.argv[2])
base_dir = sys.argv[3]
size = 1024, 1024

print "~Number of hours to be running: %f" % ((float(total_num_images)*(second_delay+2))/3600)

# Run screenshots and convert to 1024x1024 jpgs every 5 to save space
for i in xrange(total_num_images):
	filename = datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + '.png'
	filepath = os.path.join(base_dir,filename)
	bash_cmd = 'screencapture -xS ' + filepath
	process = subprocess.Popen(bash_cmd.split())
	if (i % 5) ==4:
		time.sleep(2)
		filelist = os.listdir(base_dir)
		# Define an output queue
		output = mp.Queue()
		processes = [mp.Process(target=resize_img,args=(size,os.path.join(base_dir,f),output))
						for f in filelist if os.path.splitext(f)[1]=='.png']
		# Run processes
		for p in processes:
			p.start()
		# Exit completed processes
		for p in processes:
			p.join()
			#print '%s.exitcode = %s' % (p.name, p.exitcode)
		# Get process results from the output queue
		results = [output.get() for p in processes]
		#print results
	time.sleep(second_delay) # delay by minute delay