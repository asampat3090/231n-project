import os
import numpy as np
from PIL import Image
import shutil
import psutil

tasks = ['calendar','email','programming','social_media','word_processing','web_shopping',
           'finance','news','music_editing','photo_editing','video_editing','watching_video','web_browsing','web_forum']
task_to_idx = {t: i for i, t in enumerate(tasks)}

# Loop through all files 
for f in os.listdir('.'):
	try:
		img = Image.open(f)
	except IOError: 
		print "Cannot open image %s" % f
		continue
	# Show image and wait for raw input:
	img.show()
	print "Choose from the following options:"
	print "0: calendar"
	print "1: email"
	print "2: programming"
	print "3: social_media"
	print "4: word_processing"
	print "5: web_shopping"
	print "6: finance"
	print "7: news"
	print "8: music_editing"
	print "9: photo_editing"
	print "10: video_editing"
	print "11: watching_video"
	print "12: web_browsing"
	print "13: web_forum"
	print "d: DELETE"
	variable = raw_input('What do you want to do?: ')
	if variable=="d":
		os.remove(f)
		print "Deleted %s" % f
	elif int(variable)<14:
		new_path = os.path.join('/Users/anandsampat/project_231n/data',tasks[int(variable)])
		shutil.move(f,new_path)
		print "Moved file from %s to %s" % (os.path.abspath(f),os.path.abspath(new_path))
	else: 
		print "Did not recognize input %s" % variable
	# remove display
	for pid in psutil.pids():
		proc = psutil.Process(pid)
		if proc.name() == "Preview":
			proc.kill()