# -*- coding: utf-8 -*-

from GoogleScraper import scrape_with_config, GoogleSearchError

# simulating a image search for all search engines that support image search.
# Then download all found images :)

target_directory = 'social_media/'

# word_processing
#search_term_arr = ['word perfect word processor screenshots','microsoft word 95 screenshots','microsoft word 2010 screenshots']
# email
#search_term_arr = ['email inbox screenshots','windows live email inbox screenshots']
# calendar
#search_term_arr = ['google calendar screenshot','outlook calendar screenshot','apple calendar screenshot','desktop calendar application screenshot']
#search_term_arr = ['calendar screenshots','yahoo calendar screenshots']
# social_media
search_term_arr = ['pinterest screenshots, linkedin screenshots']
#search_term_arr = ['linkedin screenshots','pinterest screenshots','tumblr screenshots']
# programming
#search_term_arr = ['terminal coding desktop screenshots','eclipse IDE screenshots','sublime text screenshots','vim screenshots']
#search_term_arr = ['pycharm ide screenshots','visual studio screenshots','emacs screenshots']
# web_shopping
#search_term_arr = ['web shopping store screenshots','amazon shopping website screenshots','ebay shopping website screenshots','shopping online screenshots','alibaba shopping online screenshots']
#search_term_arr = ['newegg website screenshots','bestbuy website screenshots']
# finance
#search_term_arr = ['web finances screenshots','turbo tax screenshots','financial planning screenshots','financial software screenshots','financial models microsoft excel screenshots']
#search_term_arr = ['financial models in google spreadsheets','finances charts screenshots']
# news
#search_term_arr = ['online news article screenshot','cnn.com articles screenshots','new york times articles screenshots','wall street journal articles screenshots','tabloids online articles screenshots','online front page news screenshots']
#search_term_arr = ['bbc news front page screenshot','bbc news front page screenshot']
# video_editing
#search_term_arr = ['video editing screenshots','imovie editing screenshots', 'final cut pro editing screenshots','windows movie maker editing screenshots','sony vegas pro editing screenshots','adobe premiere editing screenshots']
#search_term_arr = ['roxio video editor software screenshot','Pinnacle Studio video editor software screenshot','Lumiera video editor software screenshot']
# music_editing
#search_term_arr = ['audacity editing screenshots','garageband editing screenshots','logic pro editing screenshots','audio editing screenshots','sony sound forge editing screenshots']
# picture_editing
#search_term_arr = ['gimp photo editing screenshots','paint.net editing screenshots','adobe illustrator editing screenshots','adobe photoshop editing screenshots','aperture editing screenshots']
#search_term_arr = ['paintshop pro photo editing software screenshot','pixelmator pro photo editing software screenshot']
# watching_video
#search_term_arr = ['youtube video page screenshots','netflix desktop screenshots','hulu desktop screenshots','hbo go online screenshots','amazon prime video screenshots']
#search_term_arr = ['yidio videos website screenshots']
# web_browsing
#search_term_arr = ['web browsing screenshots','web browsing google results screenshots','safari web browsing screenshots','mozilla firefox browser screenshots','google chrome browser screenshots','internet explorer browser screenshots','wikipedia browsing screenshots']
# web_forum
# search_term_arr = ['website forum screenshots','reddit screenshots','craigslist forum screenshots','stackoverflow online forum screenshots']
#search_term_arr = ['irc chat forum screenshots','best chat rooms screenshot']

for s in search_term_arr:
    # See in the config.cfg file for possible values
    config = {
        'SCRAPING': {
            'keyword': s, # :D hehe have fun my dear friends
            'search_engines': 'yandex,google,bing,yahoo', # duckduckgo not supported
            'search_type': 'image',
            'scrape_method': 'selenium'
        },
        'GLOBAL': {
            'do_caching': 'True'
        }
    }

    try:
        search = scrape_with_config(config)
    except GoogleSearchError as e:
        print(e)

    image_urls = []

    for serp in search.serps:
        image_urls.extend(
            [link.link for link in serp.links]
        )

    #print('[i] Going to scrape {num} images and saving them in "{dir}"'.format(
    #    num=len(image_urls),
    #    dir=target_directory
    #))

    print('[i] Going to scrape {num} images and saving them in "{dir}"'.format(
        num=100,
        dir=target_directory
    ))


    import threading,requests, os, urllib

    # In our case we want to download the
    # images as fast as possible, so we use threads.
    class FetchResource(threading.Thread):
        """Grabs a web resource and stores it in the target directory.
        Args:
            target: A directory where to save the resource.
            urls: A bunch of urls to grab
        """
        def __init__(self, target, urls):
            super().__init__()
            self.target = target
            self.urls = urls

        def run(self):
            for url in self.urls:
                url = urllib.parse.unquote(url)
                with open(os.path.join(self.target, url.split('/')[-1]), 'wb') as f:
                    try:
                        content = requests.get(url).content
                        f.write(content)
                    except Exception as e:
                        pass
                    print('[+] Fetched {}'.format(url))

    # make a directory for the results
    try:
        os.mkdir(target_directory)
    except FileExistsError:
        pass

    # fire up 100 threads to get the images
    num_threads = 200

    threads = [FetchResource(target_directory, []) for i in range(num_threads)]

    while image_urls:
        for t in threads:
            try:
                t.urls.append(image_urls.pop())
            except IndexError as e:
                break

    threads = [t for t in threads if t.urls]

    for t in threads:
        t.start()

    for t in threads:
        t.join()
